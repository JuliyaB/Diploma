package com.Bondarenko.service;

import com.Bondarenko.model.SightKinds;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public interface SightKindsService {

    SightKinds save(SightKinds sightKinds);

    Boolean delete(int id);

    SightKinds update(SightKinds sightKinds);

    SightKinds findById(int id);

    SightKinds findByNameSightKinds(String nameSightKinds);

    Collection<SightKinds> findAll();
}

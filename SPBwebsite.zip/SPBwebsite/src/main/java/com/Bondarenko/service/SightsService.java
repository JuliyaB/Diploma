package com.Bondarenko.service;

import com.Bondarenko.model.Sights;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;

@Service
public interface SightsService {

    Sights save(Sights sights);

    Boolean delete(int id);

    Sights update(Sights sights);

    Sights findById(int id);

    Sights findByNameSights(String nameSights);

    Collection<Sights> findAll();

    List<Sights> findByKeyword(String keyword);
}

package com.Bondarenko.service;

import com.Bondarenko.model.DayTrip;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;

@Service
public interface DayTripService {

    DayTrip save(DayTrip dayTrip);

    Boolean delete(int id);

    DayTrip update(DayTrip dayTrip);

    DayTrip findById(int id);

    DayTrip findByNameDayTrip(String nameDayTrip);

    Collection<DayTrip> findAll();

    List<DayTrip> findByKeyword(String keyword);
}

package com.Bondarenko.service.impl;

import com.Bondarenko.model.Photos;
import com.Bondarenko.repository.PhotosRepository;
import com.Bondarenko.service.PhotosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class PhotosServiceImpl implements PhotosService {

    @Autowired
    private PhotosRepository photosRepository;

    @Override
    public Photos save(Photos photos) {
        return photosRepository.save(photos);
    }

    @Override
    public Boolean delete(int id) {
        if (photosRepository.existsById(id)) {
            photosRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public Photos update(Photos photos) {
        return photosRepository.save(photos);
    }

    @Override
    public Photos findById(int id) {
        return photosRepository.findById(id).get();
    }

    @Override
    public List<Photos> findAll() {
        return (List<Photos>) photosRepository.findAll();
    }

    @Override
    public List<Photos> findByKeyword(String keyword){
        return photosRepository.findByKeyword(keyword);
    }
}

package com.Bondarenko.service.impl;

import com.Bondarenko.model.SightKinds;
import com.Bondarenko.repository.SightKindsRepository;
import com.Bondarenko.service.SightKindsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class SightKindsServiceImpl implements SightKindsService {

    @Autowired
    private SightKindsRepository sightKindsRepository;

    @Override
    public SightKinds save(SightKinds sightKinds) {
        return sightKindsRepository.save(sightKinds);
    }

    @Override
    public Boolean delete(int id) {
        if (sightKindsRepository.existsById(id)) {
            sightKindsRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public SightKinds update(SightKinds sightKinds) {
        return sightKindsRepository.save(sightKinds);
    }

    @Override
    public SightKinds findById(int id) {
        return sightKindsRepository.findById(id).get();
    }

    @Override
    public SightKinds findByNameSightKinds(String nameSightKinds) {
        return sightKindsRepository.findByNameSightKinds(nameSightKinds);
    }

    @Override
    public List<SightKinds> findAll() {
        return (List<SightKinds>) sightKindsRepository.findAll();
    }
}

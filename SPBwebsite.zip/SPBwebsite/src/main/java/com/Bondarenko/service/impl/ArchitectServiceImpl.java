package com.Bondarenko.service.impl;

import com.Bondarenko.model.Architect;
import com.Bondarenko.repository.ArchitectRepository;
import com.Bondarenko.service.ArchitectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class ArchitectServiceImpl implements ArchitectService {

    @Autowired
    private ArchitectRepository architectRepository;

    @Override
    public Architect save(Architect architect) {
        return architectRepository.save(architect);
    }

    @Override
    public Boolean delete(int id) {
        if (architectRepository.existsById(id)) {
            architectRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public Architect update(Architect architect) {
        return architectRepository.save(architect);
    }

    @Override
    public Architect findById(int id) {
        return architectRepository.findById(id).get();
    }

    @Override
    public Architect findByArchitectName(String architectName) {
        return architectRepository.findByArchitectName(architectName);
    }

    @Override
    public List<Architect> findAll() {
        return (List<Architect>) architectRepository.findAll();
    }

    @Override
    public List<Architect> findByKeyword(String keyword){
        return architectRepository.findByKeyword(keyword);
    }
}

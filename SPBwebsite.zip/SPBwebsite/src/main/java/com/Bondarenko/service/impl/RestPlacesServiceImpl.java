package com.Bondarenko.service.impl;

import com.Bondarenko.model.RestPlaces;
import com.Bondarenko.repository.RestPlacesRepository;
import com.Bondarenko.service.RestPlacesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class RestPlacesServiceImpl implements RestPlacesService {

    @Autowired
    private RestPlacesRepository restPlacesRepository;

    @Override
    public RestPlaces save(RestPlaces restPlaces) {
        return restPlacesRepository.save(restPlaces);
    }

    @Override
    public Boolean delete(int id) {
        if (restPlacesRepository.existsById(id)) {
            restPlacesRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public RestPlaces update(RestPlaces restPlaces) {
        return restPlacesRepository.save(restPlaces);
    }

    @Override
    public RestPlaces findById(int id) {
        return restPlacesRepository.findById(id).get();
    }

    @Override
    public RestPlaces findByNameRestPlaces(String nameRestPlaces) {
        return restPlacesRepository.findByNameRestPlaces(nameRestPlaces);
    }

    @Override
    public List<RestPlaces> findAll() {
        return (List<RestPlaces>) restPlacesRepository.findAll();
    }

    @Override
    public List<RestPlaces> findByKeyword(String keyword){
        return restPlacesRepository.findByKeyword(keyword);
    }

}

package com.Bondarenko.service;

import com.Bondarenko.model.RestKinds;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public interface RestKindsService {

    RestKinds save(RestKinds restKinds);

    Boolean delete(int id);

    RestKinds update(RestKinds restKinds);

    RestKinds findById(int id);

    RestKinds findByNameRestKinds(String nameRestKinds);

    Collection<RestKinds> findAll();
}

package com.Bondarenko.service.impl;

import com.Bondarenko.model.DayTrip;
import com.Bondarenko.repository.DayTripRepository;
import com.Bondarenko.service.DayTripService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class DayTripServiceImpl implements DayTripService {

    @Autowired
    private DayTripRepository dayTripRepository;

    @Override
    public DayTrip save(DayTrip dayTrip) {
        return dayTripRepository.save(dayTrip);
    }

    @Override
    public Boolean delete(int id) {
        if (dayTripRepository.existsById(id)) {
            dayTripRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public DayTrip update(DayTrip dayTrip) {
        return dayTripRepository.save(dayTrip);
    }

    @Override
    public DayTrip findById(int id) {
        return dayTripRepository.findById(id).get();
    }

    @Override
    public DayTrip findByNameDayTrip(String nameDayTrip) {
        return dayTripRepository.findByNameDayTrip(nameDayTrip);
    }

    @Override
    public List<DayTrip> findAll() {
        return (List<DayTrip>) dayTripRepository.findAll();
    }

    @Override
    public List<DayTrip> findByKeyword(String keyword){
        return dayTripRepository.findByKeyword(keyword);
    }
}

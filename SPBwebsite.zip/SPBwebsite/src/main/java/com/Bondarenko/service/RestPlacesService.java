package com.Bondarenko.service;

import com.Bondarenko.model.RestPlaces;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;

@Service
public interface RestPlacesService {

    RestPlaces save(RestPlaces restPlaces);

    Boolean delete(int id);

    RestPlaces update(RestPlaces restPlaces);

    RestPlaces findById(int id);

    RestPlaces findByNameRestPlaces(String nameRestPlaces);

    Collection<RestPlaces> findAll();

    List<RestPlaces> findByKeyword(String keyword);
}

package com.Bondarenko.service.impl;

import com.Bondarenko.model.RestKinds;
import com.Bondarenko.repository.RestKindsRepository;
import com.Bondarenko.service.RestKindsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class RestKindsServiceImpl implements RestKindsService {

    @Autowired
    private RestKindsRepository restKindsRepository;

    @Override
    public RestKinds save(RestKinds restKinds) {
        return restKindsRepository.save(restKinds);
    }

    @Override
    public Boolean delete(int id) {
        if (restKindsRepository.existsById(id)) {
            restKindsRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public RestKinds update(RestKinds restKinds) {
        return restKindsRepository.save(restKinds);
    }

    @Override
    public RestKinds findById(int id) {
        return restKindsRepository.findById(id).get();
    }

    @Override
    public RestKinds findByNameRestKinds(String nameRestKinds) {
        return restKindsRepository.findByNameRestKinds(nameRestKinds);
    }

    @Override
    public List<RestKinds> findAll() {
        return (List<RestKinds>) restKindsRepository.findAll();
    }
}

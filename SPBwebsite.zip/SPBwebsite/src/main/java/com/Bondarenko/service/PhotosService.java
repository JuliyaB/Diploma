package com.Bondarenko.service;

import com.Bondarenko.model.Photos;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;

@Service
public interface PhotosService {

    Photos save(Photos photos);

    Boolean delete(int id);

    Photos update(Photos photos);

    Photos findById(int id);

    Collection<Photos> findAll();

    List<Photos> findByKeyword(String keyword);
}

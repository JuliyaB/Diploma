package com.Bondarenko.service;

import com.Bondarenko.model.Architect;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public interface ArchitectService {

    Architect save(Architect architect);

    Boolean delete(int id);

    Architect update(Architect architect);

    Architect findById(int id);

    Architect findByArchitectName(String architectName);

    Collection<Architect> findAll();
}

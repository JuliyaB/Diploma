package com.Bondarenko.service.impl;

import com.Bondarenko.model.Sights;
import com.Bondarenko.repository.SightsRepository;
import com.Bondarenko.service.SightsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class SightsServiceImpl implements SightsService {

    @Autowired
    private SightsRepository sightsRepository;

    @Override
    public Sights save(Sights sights) {
        return sightsRepository.save(sights);
    }

    @Override
    public Boolean delete(int id) {
        if (sightsRepository.existsById(id)) {
            sightsRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public Sights update(Sights sights) {
        return sightsRepository.save(sights);
    }

    @Override
    public Sights findById(int id) {
        return sightsRepository.findById(id).get();
    }

    @Override
    public Sights findByNameSights(String nameSights) {
        return sightsRepository.findByNameSights(nameSights);
    }

    @Override
    public List<Sights> findAll() {
        return (List<Sights>) sightsRepository.findAll();
    }

    @Override
    public List<Sights> findByKeyword(String keyword){
        return sightsRepository.findByKeyword(keyword);
    }
}

package com.Bondarenko.controller;

import com.Bondarenko.model.Architect;
import com.Bondarenko.model.User;
import com.Bondarenko.service.ArchitectService;
import com.Bondarenko.service.TaskService;
import com.Bondarenko.service.UserService;
import com.Bondarenko.utils.PassEncoding;
import com.Bondarenko.utils.Roles;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@ComponentScan
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    GlobalController globalController;

    @Autowired
    TaskService taskService;

    @Autowired
    UserService userService;

    @Autowired
    ArchitectService architectService;

    @Value("${welcome.message}")
    private String message;

    @Value("${error.message}")
    private String errorMessage;

    @RequestMapping(value = {"/", "/index"}, method = RequestMethod.GET)
    public String index(Model model) {
        logger.info("index");
        model.addAttribute("message", message);
        return "index";
    }

    @RequestMapping(value = {"/sights"}, method = RequestMethod.GET)
    public String sights(Model model) {
        logger.info("sights");
        model.addAttribute("message", message);
        return "sights";
    }

    @RequestMapping(value = {"/sight"}, method = RequestMethod.GET)
    public String sight(Model model) {
        logger.info("sight");
        model.addAttribute("message", message);
        return "sight";
    }

    @RequestMapping("/architects")
    public String architects(Model model) {
        Architect architect =new Architect();
        model.addAttribute("reqArchitect", architect);
        model.addAttribute("allArchitect", architectService.findAll());
        logger.info("architects");
        return "architects";
    }


    @RequestMapping("/login")
    public String login(Model model) {
        model.addAttribute("reqUser", new User());
        logger.info("login");
        return "login";
    }

    @RequestMapping("/cabinet")
    public String cabinet(Model model) {
        User user =new User();
        model.addAttribute("reqUser", user);
        model.addAttribute("allUser", userService.findAll());
        logger.info("cabinet");
        return "cabinet";
    }

    @RequestMapping("/admin")
    public String helloAdmin() {
        logger.info("admin");
        return "admin";
    }

    @RequestMapping("/register")
    public String register(Model model) {
        model.addAttribute("reqUser", new User());
        logger.info("register");
        return "register";
    }

    @RequestMapping(value = {"/user/register"}, method = RequestMethod.POST)
    public String register(@ModelAttribute("reqUser") User reqUser,
                           final RedirectAttributes redirectAttributes) {

        logger.info("/user/register");
        User user = userService.findByUserName(reqUser.getUsername());
        if (user != null) {
            redirectAttributes.addFlashAttribute("saveUser", "exist-name");
            return "redirect:/register";
        }
        user = userService.findByEmail(reqUser.getEmail());
        if (user != null) {
            redirectAttributes.addFlashAttribute("saveUser", "exist-email");
            return "redirect:/register";
        }

        reqUser.setPassword(PassEncoding.getInstance().passwordEncoder.encode(reqUser.getPassword()));
        reqUser.setRole(Roles.ROLE_USER.getValue());

        if (userService.save(reqUser) != null) {
            redirectAttributes.addFlashAttribute("saveUser", "success");
        } else {
            redirectAttributes.addFlashAttribute("saveUser", "fail");
        }

        return "redirect:/register";
    }

}

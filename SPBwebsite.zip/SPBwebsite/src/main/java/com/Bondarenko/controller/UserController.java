package com.Bondarenko.controller;

import com.Bondarenko.model.User;
import com.Bondarenko.service.*;
import com.Bondarenko.utils.PassEncoding;
import com.Bondarenko.utils.Roles;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Set;

@Controller
@ComponentScan
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    GlobalController globalController;

    @Autowired
    UserService userService;

    @Autowired
    ArchitectService architectService;

    @Autowired
    SightsService sightsService;

    @Autowired
    RestPlacesService restPlacesService;

    @Autowired
    DayTripService dayTripService;

    @Autowired
    PhotosService photosService;

    @RequestMapping(value = {"/", "/index"}, method = RequestMethod.GET)
    public String index(Model model) {
        logger.info("index");
        model.addAttribute("allUser", userService.findAll());
        return "index";
    }

    @RequestMapping(value = {"/sights"}, method = RequestMethod.GET)
    public String sights(Model model, String keyword) {
        model.addAttribute("allUser", userService.findAll());

        if (keyword!=null){
            model.addAttribute("allSights", sightsService.findByKeyword(keyword));
        }else {
            model.addAttribute("allSights", sightsService.findAll());
        }

        logger.info("sights");
        return "sights";
    }

    @RequestMapping(value = {"/gardens"}, method = RequestMethod.GET)
    public String gardens(Model model, String keyword) {
        model.addAttribute("allUser", userService.findAll());

        if (keyword!=null){
            model.addAttribute("allGardens", sightsService.findByKeyword(keyword));
        }else {
            model.addAttribute("allGardens", sightsService.findAll());
        }

        logger.info("gardens");
        return "gardens";
    }

    @RequestMapping(value = {"/building"}, method = RequestMethod.GET)
    public String building(Model model, String keyword) {
        model.addAttribute("allUser", userService.findAll());

        if (keyword!=null){
            model.addAttribute("allBuilding", sightsService.findByKeyword(keyword));
        }else {
            model.addAttribute("allBuilding", sightsService.findAll());
        }

        logger.info("building");
        return "building";
    }

    @RequestMapping(value = {"/streets"}, method = RequestMethod.GET)
    public String streets(Model model, String keyword) {
        model.addAttribute("allUser", userService.findAll());

        if (keyword!=null){
            model.addAttribute("allStreets", sightsService.findByKeyword(keyword));
        }else {
            model.addAttribute("allStreets", sightsService.findAll());
        }

        logger.info("streets");
        return "streets";
    }

    @RequestMapping(value = {"/monuments"}, method = RequestMethod.GET)
    public String monuments(Model model, String keyword) {
        model.addAttribute("allUser", userService.findAll());

        if (keyword!=null){
            model.addAttribute("allMonuments", sightsService.findByKeyword(keyword));
        }else {
            model.addAttribute("allMonuments", sightsService.findAll());
        }

        logger.info("monuments");
        return "monuments";
    }

    @RequestMapping(value = {"/bridges"}, method = RequestMethod.GET)
    public String bridges(Model model, String keyword) {
        model.addAttribute("allUser", userService.findAll());

        if (keyword!=null){
            model.addAttribute("allBridges", sightsService.findByKeyword(keyword));
        }else {
            model.addAttribute("allBridges", sightsService.findAll());
        }

        logger.info("bridges");
        return "bridges";
    }

    @RequestMapping(value = {"/cafes"}, method = RequestMethod.GET)
    public String cafes(Model model, String keyword) {
        model.addAttribute("allUser", userService.findAll());

        if (keyword!=null){
            model.addAttribute("allCafes", restPlacesService.findByKeyword(keyword));
        }else {
            model.addAttribute("allCafes", restPlacesService.findAll());
        }

        logger.info("cafes");
        return "cafes";
    }

    @RequestMapping(value = {"/hotels"}, method = RequestMethod.GET)
    public String hotels(Model model, String keyword) {
        model.addAttribute("allUser", userService.findAll());

        if (keyword!=null){
            model.addAttribute("allHotels", restPlacesService.findByKeyword(keyword));
        }else {
            model.addAttribute("allHotels", restPlacesService.findAll());
        }

        logger.info("hotels");
        return "hotels";
    }

    @RequestMapping("/architects")
    public String architects(Model model, String keyword) {
        model.addAttribute("allUser", userService.findAll());

        if (keyword!=null){
            model.addAttribute("allArchitect", architectService.findByKeyword(keyword));
        }else {
            model.addAttribute("allArchitect", architectService.findAll());
        }

        logger.info("architects");
        return "architects";
    }

    @RequestMapping("/dayTrips")
    public String dayTrips(Model model, String keyword) {
        model.addAttribute("photos", photosService.findAll());
        model.addAttribute("allUser", userService.findAll());

        if (keyword!=null){
            model.addAttribute("allDayTrips", dayTripService.findByKeyword(keyword));
        }else {
            model.addAttribute("allDayTrips", dayTripService.findAll());
        }

        logger.info("dayTrips");
        return "dayTrips";
    }

    @RequestMapping("/photos")
    public String photos(Model model, String keyword) {
        model.addAttribute("allUser", userService.findAll());

        if (keyword!=null){
            model.addAttribute("photos", photosService.findByKeyword(keyword));
        }else {
            model.addAttribute("photos", photosService.findAll());
        }

        logger.info("photos");
        return "photos";
    }

    @RequestMapping("/login")
    public String login(Model model) {
        model.addAttribute("reqUser", new User());
        logger.info("login");
        return "login";
    }

    @RequestMapping("/cabinet")
    public String cabinet(Model model) {
        model.addAttribute("allUser", userService.findAll());
        model.addAttribute("allDayTrip", dayTripService.findAll());
        logger.info("cabinet");
        return "cabinet";
    }


    @RequestMapping("/admin")
    public String helloAdmin() {
        logger.info("admin");
        return "admin";
    }

    @RequestMapping("/register")
    public String register(Model model) {
        model.addAttribute("reqUser", new User());
        logger.info("register");
        return "register";
    }

    @RequestMapping(value = {"/user/register"}, method = RequestMethod.POST)
    public String register(@ModelAttribute("reqUser") User reqUser,
                           final RedirectAttributes redirectAttributes) {

        logger.info("/user/register");
        User user = userService.findByUserName(reqUser.getUsername());
        if (user != null) {
            redirectAttributes.addFlashAttribute("saveUser", "exist-name");
            return "redirect:/register";
        }
        user = userService.findByEmail(reqUser.getEmail());
        if (user != null) {
            redirectAttributes.addFlashAttribute("saveUser", "exist-email");
            return "redirect:/register";
        }

        reqUser.setPassword(PassEncoding.getInstance().passwordEncoder.encode(reqUser.getPassword()));
        reqUser.setRole(Roles.ROLE_USER.getValue());

        if (userService.save(reqUser) != null) {
            redirectAttributes.addFlashAttribute("saveUser", "success");
        } else {
            redirectAttributes.addFlashAttribute("saveUser", "fail");
        }

        return "redirect:/register";
    }

}

package com.Bondarenko.controller;

import com.Bondarenko.model.*;
import com.Bondarenko.service.*;
import com.Bondarenko.utils.PassEncoding;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Set;

@Controller
@EnableWebMvc
@ComponentScan
public class TodoController {

    private static final Logger logger = LoggerFactory.getLogger(TodoController.class);

    @Autowired
    UserService userService;

    @Autowired
    ArchitectService architectService;

    @Autowired
    SightsService sightsService;

    @Autowired
    RestPlacesService restPlacesService;

    @Autowired
    DayTripService dayTripService;

    @Autowired
    PhotosService photosService;

    @RequestMapping(value = "/getUserPhoto/{id}")
    public void getUserPhoto(HttpServletResponse response, @PathVariable("id") int id,
                             final RedirectAttributes redirectAttributes) throws Exception {
        response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
        logger.info("/getUserPhoto/");
        User user = userService.findById(id);
        byte[] bytes = user.getUserPhoto();
        if (bytes != null) {
            InputStream inputStream = new ByteArrayInputStream(bytes);
            IOUtils.copy(inputStream, response.getOutputStream());
        } else {
            redirectAttributes.addFlashAttribute("msg", "not");
        }
    }

    @RequestMapping(value = {"/user/editUser"}, method = RequestMethod.POST)
    public String editTodo(@ModelAttribute("editUser") User editUser,
                           @RequestParam("photo") MultipartFile photo,
                           Model model) {
        logger.info("/user/editUser");
        try {
            model.addAttribute("allUser", userService.findAll());
            User user = userService.findById(editUser.getId());
            if (!user.equals(editUser)) {
                byte[] photoBytes = photo.getBytes();
                editUser.setUserPhoto(photoBytes);
                editUser.setPassword(PassEncoding.getInstance().passwordEncoder.encode(editUser.getPassword()));
                userService.update(editUser);
                model.addAttribute("msg", "success");
            } else {
                model.addAttribute("msg", "same");
            }
        } catch (Exception e) {
            model.addAttribute("msg", "fail");
            logger.error("editUser: " + e.getMessage());
        }
        model.addAttribute("editTodo", editUser);
        return "edit";
    }


    @RequestMapping(value = "/user/{operation}/{id}", method = RequestMethod.GET)
    public String todoOperation(@PathVariable("operation") String operation,
                                @PathVariable("id") int id, final RedirectAttributes redirectAttributes,
                                Model model) {

        logger.info("/user/operation: {} ", operation);
        if (operation.equals("delete")) {
            if (userService.delete(id)) {
                redirectAttributes.addFlashAttribute("msg", "del");
                redirectAttributes.addFlashAttribute("msgText", " Task deleted permanently");
            } else {
                redirectAttributes.addFlashAttribute("msg", "del_fail");
                redirectAttributes.addFlashAttribute("msgText", " Task could not deleted. Please try later");
            }
        } else if (operation.equals("edit")) {
            User editUser = userService.findById(id);
            if (editUser != null) {
                model.addAttribute("editUser", editUser);
                model.addAttribute("allUser", userService.findAll());
                return "edit";
            } else {
                redirectAttributes.addFlashAttribute("msg", "notfound");
            }
        }
        if (operation.equals("deletePhotos")) {
            if (photosService.delete(id)) {
                redirectAttributes.addFlashAttribute("msg", "del");
                redirectAttributes.addFlashAttribute("msgText", " Task deleted permanently");
            } else {
                redirectAttributes.addFlashAttribute("msg", "del_fail");
                redirectAttributes.addFlashAttribute("msgText", " Task could not deleted. Please try later");
            }
        }
        return "redirect:/cabinet";
    }

    @RequestMapping(value = "/architect/{id}", method = RequestMethod.GET)
    public String architect(@PathVariable("id") int id, Model model,
                            final RedirectAttributes redirectAttributes) {
        logger.info("/architect/{}", id);
        Architect architect = architectService.findById(id);
        if (architect != null) {
            Set<Sights> sights = architect.getSights_architect();
            model.addAttribute("sights", sights);
            model.addAttribute("architect", architect);
            model.addAttribute("allUser", userService.findAll());
            return "architect";
        } else {
            redirectAttributes.addFlashAttribute("msg", "notfound");
        }
        return "redirect:/architects";
    }

    @RequestMapping(value = "/getArchitectPhoto/{id}")
    public void getArchitectPhoto(HttpServletResponse response, @PathVariable("id") int id) throws Exception {
        response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
        logger.info("/getArchitectPhoto/");
        Architect architect = architectService.findById(id);
        byte[] bytes = architect.getPhotoArchitect();
        InputStream inputStream = new ByteArrayInputStream(bytes);
        IOUtils.copy(inputStream, response.getOutputStream());
    }

    @RequestMapping(value = "/sight/{id}", method = RequestMethod.GET)
    public String sight(@PathVariable("id") int id, Model model,
                        final RedirectAttributes redirectAttributes) {
        logger.info("/sight/{}", id);
        Sights sights = sightsService.findById(id);
        if (sights != null) {
            Set<Architect> architect = sights.getArchitect_sights();
            model.addAttribute("architect", architect);
            model.addAttribute("sight", sights);
            model.addAttribute("allUser", userService.findAll());
            return "sight";
        } else {
            redirectAttributes.addFlashAttribute("msg", "notfound");
        }
        return "redirect:/sights";
    }

    @RequestMapping(value = "/getPhotoSights/{id}")
    public void getPhotoSights(HttpServletResponse response, @PathVariable("id") int id) throws Exception {
        response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
        logger.info("/getPhotoSights/");
        Sights sights = sightsService.findById(id);
        byte[] bytes = sights.getPhotoSights();
        InputStream inputStream = new ByteArrayInputStream(bytes);
        IOUtils.copy(inputStream, response.getOutputStream());
    }

    @RequestMapping(value = "/garden/{id}", method = RequestMethod.GET)
    public String garden(@PathVariable("id") int id, Model model,
                         final RedirectAttributes redirectAttributes) {
        logger.info("/garden/{}", id);
        Sights sights = sightsService.findById(id);
        if (sights != null) {
            Set<Architect> architect = sights.getArchitect_sights();
            model.addAttribute("architect", architect);
            model.addAttribute("garden", sights);
            model.addAttribute("allUser", userService.findAll());
            return "garden";
        } else {
            redirectAttributes.addFlashAttribute("msg", "notfound");
        }
        return "redirect:/gardens";
    }

    @RequestMapping(value = "/build/{id}", method = RequestMethod.GET)
    public String build(@PathVariable("id") int id, Model model,
                        final RedirectAttributes redirectAttributes) {
        logger.info("/build/{}", id);
        Sights sights = sightsService.findById(id);
        if (sights != null) {
            Set<Architect> architect = sights.getArchitect_sights();
            model.addAttribute("architect", architect);
            model.addAttribute("build", sights);
            model.addAttribute("allUser", userService.findAll());
            return "build";
        } else {
            redirectAttributes.addFlashAttribute("msg", "notfound");
        }
        return "redirect:/building";
    }

    @RequestMapping(value = "/street/{id}", method = RequestMethod.GET)
    public String street(@PathVariable("id") int id, Model model,
                         final RedirectAttributes redirectAttributes) {
        logger.info("/street/{}", id);
        Sights sights = sightsService.findById(id);
        if (sights != null) {
            Set<Architect> architect = sights.getArchitect_sights();
            model.addAttribute("architect", architect);
            model.addAttribute("street", sights);
            model.addAttribute("allUser", userService.findAll());
            return "street";
        } else {
            redirectAttributes.addFlashAttribute("msg", "notfound");
        }
        return "redirect:/streets";
    }

    @RequestMapping(value = "/monument/{id}", method = RequestMethod.GET)
    public String monument(@PathVariable("id") int id, Model model,
                           final RedirectAttributes redirectAttributes) {
        logger.info("/monument/{}", id);
        Sights sights = sightsService.findById(id);
        if (sights != null) {
            Set<Architect> architect = sights.getArchitect_sights();
            model.addAttribute("architect", architect);
            model.addAttribute("monument", sights);
            model.addAttribute("allUser", userService.findAll());
            return "monument";
        } else {
            redirectAttributes.addFlashAttribute("msg", "notfound");
        }
        return "redirect:/monuments";
    }

    @RequestMapping(value = "/bridge/{id}", method = RequestMethod.GET)
    public String bridge(@PathVariable("id") int id, Model model,
                         final RedirectAttributes redirectAttributes) {
        logger.info("/bridge/{}", id);
        Sights sights = sightsService.findById(id);
        if (sights != null) {
            Set<Architect> architect = sights.getArchitect_sights();
            model.addAttribute("architect", architect);
            model.addAttribute("bridge", sights);
            model.addAttribute("allUser", userService.findAll());
            return "bridge";
        } else {
            redirectAttributes.addFlashAttribute("msg", "notfound");
        }
        return "redirect:/bridges";
    }

    @RequestMapping(value = "/getPhotoRestPlaces/{id}")
    public void getPhotoRestPlaces(HttpServletResponse response, @PathVariable("id") int id) throws Exception {
        response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
        logger.info("/getPhotoRestPlaces/");
        RestPlaces restPlaces = restPlacesService.findById(id);
        byte[] bytes = restPlaces.getPhotoRestPlaces();
        InputStream inputStream = new ByteArrayInputStream(bytes);
        IOUtils.copy(inputStream, response.getOutputStream());
    }

    @RequestMapping(value = "/cafe/{id}", method = RequestMethod.GET)
    public String cafe(@PathVariable("id") int id, Model model,
                       final RedirectAttributes redirectAttributes) {
        logger.info("/cafe/{}", id);
        RestPlaces restPlaces = restPlacesService.findById(id);
        if (restPlaces != null) {
            model.addAttribute("cafe", restPlaces);
            model.addAttribute("allUser", userService.findAll());
            return "cafe";
        } else {
            redirectAttributes.addFlashAttribute("msg", "notfound");
        }
        return "redirect:/cafes";
    }

    @RequestMapping(value = "/hotel/{id}", method = RequestMethod.GET)
    public String hotel(@PathVariable("id") int id, Model model,
                        final RedirectAttributes redirectAttributes) {
        logger.info("/hotel/{}", id);
        RestPlaces restPlaces = restPlacesService.findById(id);
        if (restPlaces != null) {
            model.addAttribute("hotel", restPlaces);
            model.addAttribute("allUser", userService.findAll());
            return "hotel";
        } else {
            redirectAttributes.addFlashAttribute("msg", "notfound");
        }
        return "redirect:/hotels";
    }

    @RequestMapping(value = "/addDayTrip", method = RequestMethod.GET)
    public String addDayTrip(Model model) {
        model.addAttribute("allUser", userService.findAll());
        model.addAttribute("reqDayTrip", new DayTrip());
        model.addAttribute("sightsList", sightsService.findAll());
        model.addAttribute("restPlacesList", restPlacesService.findAll());
        model.addAttribute("allUser", userService.findAll());
        logger.info("addDayTrip");
        return "addDayTrip";
    }

    @RequestMapping(value = {"/user/addDayTrip"}, method = RequestMethod.POST)
    public String addSights(@ModelAttribute("reqDayTrip") DayTrip reqDayTrip,
                            final RedirectAttributes redirectAttributes) {

        logger.info("/user/addDayTrip");
        DayTrip dayTrip = dayTripService.findByNameDayTrip(reqDayTrip.getNameDayTrip());
        if (dayTrip != null) {
            redirectAttributes.addFlashAttribute("saveDayTrip", "exist-name");
            return "redirect:/addDayTrip";
        }

        if (dayTripService.save(reqDayTrip) != null) {
            return "redirect:/cabinet";
        } else {
            redirectAttributes.addFlashAttribute("saveDayTrip", "fail");
        }

        return "redirect:/addDayTrip";
    }

    @RequestMapping("/addPhotos")
    public String addPhotos(Model model) {
        model.addAttribute("dayTripList", dayTripService.findAll());
        model.addAttribute("allUser", userService.findAll());
        model.addAttribute("reqPhotos", new Photos());
        model.addAttribute("allUser", userService.findAll());
        logger.info("addPhotos");
        return "addPhotos";
    }

    @RequestMapping(value = {"/user/addPhotos"}, method = RequestMethod.POST)
    public String addSights(@ModelAttribute("reqPhotos") Photos reqPhotos,
                            @RequestParam("photo") MultipartFile photo,
                            final RedirectAttributes redirectAttributes) throws Exception {

        logger.info("/user/addPhotos");
        byte[] photoBytes = photo.getBytes();
        reqPhotos.setPhotoDay(photoBytes);
        if (photosService.save(reqPhotos) != null) {
            return "redirect:/cabinet";
        } else {
            redirectAttributes.addFlashAttribute("savePhotos", "fail");
        }
        return "addPhotos";
    }

    @RequestMapping(value = {"/user/editDayTrip"}, method = RequestMethod.POST)
    public String editRestKinds(@ModelAttribute("editDayTrip") DayTrip editDayTrip, Model model) {
        logger.info("/user/editDayTrip");
        try {
            DayTrip dayTrip = dayTripService.findById(editDayTrip.getId());

            if (!dayTrip.equals(editDayTrip)) {
                dayTripService.update(editDayTrip);
                model.addAttribute("msg", "success");
            } else {
                model.addAttribute("msg", "same");
            }
        } catch (Exception e) {
            model.addAttribute("msg", "fail");
            logger.error("editRestPlaces: " + e.getMessage());
        }
        model.addAttribute("editTodo", editDayTrip);
        return "editDayTrip";
    }

    @RequestMapping(value = "/dayTrip/{id}", method = RequestMethod.GET)
    public String dayTrip(@PathVariable("id") int id, Model model,
                          final RedirectAttributes redirectAttributes) {
        logger.info("/dayTrip/{}", id);
        DayTrip dayTrip = dayTripService.findById(id);
        if (dayTrip != null) {
            model.addAttribute("dayTrips", dayTrip);
            Set<RestPlaces> restPlaces = dayTrip.getDayTrip_restPlaces();
            model.addAttribute("restPlaces", restPlaces);
            Set<Sights> sights = dayTrip.getSights_dayTrip();
            model.addAttribute("sights", sights);
            model.addAttribute("photos", photosService.findAll());
            model.addAttribute("allUser", userService.findAll());
            return "dayTrip";
        } else {
            redirectAttributes.addFlashAttribute("msg", "notfound");
        }
        return "redirect:/dayTris";
    }

    @RequestMapping(value = "/getDayTrip/{id}")
    public void getDayTrip(HttpServletResponse response, @PathVariable("id") int id) throws Exception {
        response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
        logger.info("/getDayTrip/");
        Photos photos = photosService.findById(id);
        byte[] bytes = photos.getPhotoDay();
        InputStream inputStream = new ByteArrayInputStream(bytes);
        IOUtils.copy(inputStream, response.getOutputStream());
    }

}

package com.Bondarenko.controller;

import com.Bondarenko.model.Architect;
import com.Bondarenko.service.ArchitectService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@ComponentScan
public class AdminController {

    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    @Autowired
    ArchitectService architectService;

    @RequestMapping("/addArchitect")
    public String addArchitect(Model model) {
        model.addAttribute("reqArchitect", new Architect());
        logger.info("addArchitect");
        return "addArchitect";
    }

    @RequestMapping(value = {"/admin/addArchitect"}, method = RequestMethod.POST)
    public String addArchitect(@ModelAttribute("reqArchitect") Architect reqArchitect,
                           final RedirectAttributes redirectAttributes) {

        logger.info("/admin/addArchitect");
        Architect architect = architectService.findByArchitectName(reqArchitect.getArchitectName());
        if (architect != null) {
            redirectAttributes.addFlashAttribute("saveArchitect", "exist-name");
            return "redirect:/addArchitect";
        }

        if (architectService.save(reqArchitect) != null) {
            return "redirect:/admin";
        } else {
            redirectAttributes.addFlashAttribute("saveArchitect", "fail");
        }

        return "redirect:/addArchitect";
    }
}

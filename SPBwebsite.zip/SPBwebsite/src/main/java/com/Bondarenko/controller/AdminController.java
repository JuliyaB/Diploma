package com.Bondarenko.controller;

import com.Bondarenko.model.*;
import com.Bondarenko.service.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@ComponentScan
public class AdminController {

    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    @Autowired
    ArchitectService architectService;

    @Autowired
    SightKindsService sightKindsService;

    @Autowired
    RestKindsService restKindsService;

    @Autowired
    SightsService sightsService;

    @Autowired
    UserService userService;

    @Autowired
    RestPlacesService restPlacesService;

    @RequestMapping("/addArchitect")
    public String addArchitect(Model model) {
        model.addAttribute("reqArchitect", new Architect());
        logger.info("addArchitect");
        return "addArchitect";
    }

    @RequestMapping(value = {"/admin/addArchitect"}, method = RequestMethod.POST)
    public String addArchitect(@ModelAttribute("reqArchitect") Architect reqArchitect,
                               @RequestParam("photo") MultipartFile photo,
                               final RedirectAttributes redirectAttributes) throws Exception {

        logger.info("/admin/addArchitect");
        Architect architect = architectService.findByArchitectName(reqArchitect.getArchitectName());
        if (architect != null) {
            redirectAttributes.addFlashAttribute("saveArchitect", "exist-name");
            return "redirect:/addArchitect";
        }

        byte[] photoBytes = photo.getBytes();
        reqArchitect.setPhotoArchitect(photoBytes);

        if (architectService.save(reqArchitect) != null) {
            return "redirect:/admin";
        } else {
            redirectAttributes.addFlashAttribute("saveArchitect", "fail");
        }

        return "redirect:/addArchitect";
    }

    @RequestMapping(value = {"/architect/editArchitect"}, method = RequestMethod.POST)
    public String editArchitect(@ModelAttribute("editArchitect") Architect editArchitect,
                                @RequestParam("photo") MultipartFile photo,
                                Model model) {
        logger.info("/architect/editArchitect");
        try {
            Architect architect = architectService.findById(editArchitect.getId());
            if (!architect.equals(editArchitect)) {
                byte[] photoBytes = photo.getBytes();
                editArchitect.setPhotoArchitect(photoBytes);
                architectService.update(editArchitect);
                model.addAttribute("msg", "success");
            } else {
                model.addAttribute("msg", "same");
            }
        } catch (Exception e) {
            model.addAttribute("msg", "fail");
            logger.error("editArchitect: " + e.getMessage());
        }
        model.addAttribute("editTodo", editArchitect);
        return "editArchitect";
    }

    @RequestMapping(value = "/admin/{operation}/{id}", method = RequestMethod.GET)
    public String todoOperation(@PathVariable("operation") String operation,
                                @PathVariable("id") int id, final RedirectAttributes redirectAttributes,
                                Model model) {

        logger.info("/admin/operation: {} ", operation);
        if (operation.equals("deleteArchitect")) {
            if (architectService.delete(id)) {
                redirectAttributes.addFlashAttribute("msg", "del");
                redirectAttributes.addFlashAttribute("msgText", " Task deleted permanently");
            } else {
                redirectAttributes.addFlashAttribute("msg", "del_fail");
                redirectAttributes.addFlashAttribute("msgText", " Task could not deleted. Please try later");
            }
        } else if (operation.equals("editArchitect")) {
            Architect editArchitect = architectService.findById(id);
            if (editArchitect != null) {
                model.addAttribute("editArchitect", editArchitect);
                return "editArchitect";
            } else {
                redirectAttributes.addFlashAttribute("msg", "notfound");
            }
        }
        if (operation.equals("editSightKinds")) {
            SightKinds editSightKinds = sightKindsService.findById(id);
            if (editSightKinds != null) {
                model.addAttribute("editSightKinds", editSightKinds);
                return "editSightKinds";
            } else {
                redirectAttributes.addFlashAttribute("msg", "notfound");
            }
        }
        if (operation.equals("editRestKinds")) {
            RestKinds editRestKinds = restKindsService.findById(id);
            if (editRestKinds != null) {
                model.addAttribute("editRestKinds", editRestKinds);
                return "editRestKinds";
            } else {
                redirectAttributes.addFlashAttribute("msg", "notfound");
            }
        }
        if (operation.equals("deleteSights")) {
            if (sightsService.delete(id)) {
                redirectAttributes.addFlashAttribute("msg", "del");
                redirectAttributes.addFlashAttribute("msgText", " Task deleted permanently");
            } else {
                redirectAttributes.addFlashAttribute("msg", "del_fail");
                redirectAttributes.addFlashAttribute("msgText", " Task could not deleted. Please try later");
            }
        } else if (operation.equals("editSights")) {
            Sights editSights = sightsService.findById(id);
            if (editSights != null) {
                model.addAttribute("editSights", editSights);
                model.addAttribute("sightKindsList", sightKindsService.findAll());
                model.addAttribute("architectList", architectService.findAll());
                return "editSights";
            } else {
                redirectAttributes.addFlashAttribute("msg", "notfound");
            }
        }
        if (operation.equals("deleteRestPlaces")) {
            if (restPlacesService.delete(id)) {
                redirectAttributes.addFlashAttribute("msg", "del");
                redirectAttributes.addFlashAttribute("msgText", " Task deleted permanently");
            } else {
                redirectAttributes.addFlashAttribute("msg", "del_fail");
                redirectAttributes.addFlashAttribute("msgText", " Task could not deleted. Please try later");
            }
        } else if (operation.equals("editRestPlaces")) {
            RestPlaces editRestPlaces = restPlacesService.findById(id);
            if (editRestPlaces != null) {
                model.addAttribute("editRestPlaces", editRestPlaces);
                model.addAttribute("restKindsList", restKindsService.findAll());
                return "editRestPlaces";
            } else {
                redirectAttributes.addFlashAttribute("msg", "notfound");
            }
        }
        return "redirect:/admin";
    }

    @RequestMapping("/addSightKinds")
    public String addSightKinds(Model model) {
        model.addAttribute("reqSightKinds", new SightKinds());
        logger.info("addSightKinds");
        return "addSightKinds";
    }

    @RequestMapping(value = {"/admin/addSightKinds"}, method = RequestMethod.POST)
    public String addSightKinds(@ModelAttribute("reqSightKinds") SightKinds reqSightKinds,
                                final RedirectAttributes redirectAttributes) {

        logger.info("/admin/addSightKinds");
        SightKinds sightKinds = sightKindsService.findByNameSightKinds(reqSightKinds.getNameSightKinds());
        if (sightKinds != null) {
            redirectAttributes.addFlashAttribute("saveSightKinds", "exist-name");
            return "redirect:/addSightKinds";
        }

        if (sightKindsService.save(reqSightKinds) != null) {
            return "redirect:/admin";
        } else {
            redirectAttributes.addFlashAttribute("saveSightKinds", "fail");
        }

        return "redirect:/addSightKinds";
    }

    @RequestMapping("/sightKinds")
    public String sightKinds(Model model) {
        model.addAttribute("allSightKinds", sightKindsService.findAll());
        logger.info("sightKinds");
        return "sightKinds";
    }

    @RequestMapping(value = {"/sightKinds/editSightKinds"}, method = RequestMethod.POST)
    public String editSightKinds(@ModelAttribute("editSightKinds") SightKinds editSightKinds, Model model) {
        logger.info("/sightKinds/editSightKinds");
        try {
            SightKinds sightKinds = sightKindsService.findById(editSightKinds.getId());
            if (!sightKinds.equals(editSightKinds)) {
                sightKindsService.update(editSightKinds);
                model.addAttribute("msg", "success");
            } else {
                model.addAttribute("msg", "same");
            }
        } catch (Exception e) {
            model.addAttribute("msg", "fail");
            logger.error("editSightKinds: " + e.getMessage());
        }
        model.addAttribute("editTodo", editSightKinds);
        return "editSightKinds";
    }

    @RequestMapping("/addRestKinds")
    public String addRestKinds(Model model) {
        model.addAttribute("reqRestKinds", new RestKinds());
        logger.info("addRestKinds");
        return "addRestKinds";
    }

    @RequestMapping(value = {"/admin/addRestKinds"}, method = RequestMethod.POST)
    public String addRestKinds(@ModelAttribute("reqRestKinds") RestKinds reqRestKinds,
                               final RedirectAttributes redirectAttributes) {

        logger.info("/admin/addSightKinds");
        RestKinds restKinds = restKindsService.findByNameRestKinds(reqRestKinds.getNameRestKinds());
        if (restKinds != null) {
            redirectAttributes.addFlashAttribute("saveRestKinds", "exist-name");
            return "redirect:/addRestKinds";
        }

        if (restKindsService.save(reqRestKinds) != null) {
            return "redirect:/admin";
        } else {
            redirectAttributes.addFlashAttribute("saveRestKinds", "fail");
        }

        return "redirect:/addRestKinds";
    }

    @RequestMapping("/restKinds")
    public String restKinds(Model model) {
        model.addAttribute("allRestKinds", restKindsService.findAll());
        logger.info("restKinds");
        return "restKinds";
    }

    @RequestMapping(value = {"/restKinds/editRestKinds"}, method = RequestMethod.POST)
    public String editRestKinds(@ModelAttribute("editRestKinds") RestKinds editRestKinds, Model model) {
        logger.info("/restKinds/editRestKinds");
        try {
            RestKinds restKinds = restKindsService.findById(editRestKinds.getId());
            if (!restKinds.equals(editRestKinds)) {
                restKindsService.update(editRestKinds);
                model.addAttribute("msg", "success");
            } else {
                model.addAttribute("msg", "same");
            }
        } catch (Exception e) {
            model.addAttribute("msg", "fail");
            logger.error("editRestKinds: " + e.getMessage());
        }
        model.addAttribute("editTodo", editRestKinds);
        return "editRestKinds";
    }

    @RequestMapping("/addSights")
    public String addSights(Model model) {
        model.addAttribute("reqSights", new Sights());
        model.addAttribute("sightKindsList", sightKindsService.findAll());
        model.addAttribute("architectList", architectService.findAll());
        logger.info("addSights");
        return "addSights";
    }

    @RequestMapping(value = {"/admin/addSights"}, method = RequestMethod.POST)
    public String addSights(@ModelAttribute("reqSights") Sights reqSights,
                            @RequestParam("photo") MultipartFile photo,
                            final RedirectAttributes redirectAttributes) throws Exception {

        logger.info("/admin/addSights");
        Sights sights = sightsService.findByNameSights(reqSights.getNameSights());
        if (sights != null) {
            redirectAttributes.addFlashAttribute("saveSights", "exist-name");
            return "redirect:/addSights";
        }

        byte[] photoBytes = photo.getBytes();
        reqSights.setPhotoSights(photoBytes);

        if (sightsService.save(reqSights) != null) {
            return "redirect:/admin";
        } else {
            redirectAttributes.addFlashAttribute("saveSights", "fail");
        }

        return "redirect:/addSights";
    }

    @RequestMapping(value = {"/sight/editSights"}, method = RequestMethod.POST)
    public String editRestKinds(@ModelAttribute("editSights") Sights editSights,
                                @RequestParam("photo") MultipartFile photo, Model model) throws Exception {
        logger.info("/sight/editSights");
        try {
            Sights sights = sightsService.findById(editSights.getId());
            if (!sights.equals(editSights)) {
                byte[] photoBytes = photo.getBytes();
                editSights.setPhotoSights(photoBytes);
                sightsService.update(editSights);
                model.addAttribute("msg", "success");
                model.addAttribute("sightKindsList", sightKindsService.findAll());
                model.addAttribute("architectList", architectService.findAll());
            } else {
                model.addAttribute("msg", "same");
            }
        } catch (Exception e) {
            model.addAttribute("msg", "fail");
            logger.error("editSights: " + e.getMessage());
        }
        model.addAttribute("editTodo", editSights);
        return "editSights";
    }

    @RequestMapping("/users")
    public String users(Model model, String keyword) {
        if (keyword!=null){
            model.addAttribute("allUsers", userService.findByKeyword(keyword));
        }else {
            model.addAttribute("allUsers", userService.findAll());
        }
        logger.info("users");
        return "users";
    }

    @RequestMapping("/addRestPlaces")
    public String addRestPlaces(Model model) {
        model.addAttribute("reqRestPlaces", new RestPlaces());
        model.addAttribute("restKindsList", restKindsService.findAll());
        logger.info("addRestPlaces");
        return "addRestPlaces";
    }

    @RequestMapping(value = {"/admin/addRestPlaces"}, method = RequestMethod.POST)
    public String addSights(@ModelAttribute("reqRestPlaces") RestPlaces reqRestPlaces,
                            @RequestParam("photo") MultipartFile photo,
                            final RedirectAttributes redirectAttributes) throws Exception {

        logger.info("/admin/addRestPlaces");
        RestPlaces restPlaces = restPlacesService.findByNameRestPlaces(reqRestPlaces.getNameRestPlaces());
        if (restPlaces != null) {
            redirectAttributes.addFlashAttribute("saveRestPlaces", "exist-name");
            return "redirect:/addRestPlaces";
        }

        byte[] photoBytes = photo.getBytes();
        reqRestPlaces.setPhotoRestPlaces(photoBytes);

        if (restPlacesService.save(reqRestPlaces) != null) {
            return "redirect:/admin";
        } else {
            redirectAttributes.addFlashAttribute("saveRestPlaces", "fail");
        }

        return "redirect:/addRestPlaces";
    }

    @RequestMapping(value = {"/restPlaces/editRestPlaces"}, method = RequestMethod.POST)
    public String editRestKinds(@ModelAttribute("editRestPlaces") RestPlaces editRestPlaces,
                                @RequestParam("photo") MultipartFile photo, Model model) throws Exception {
        logger.info("/restPlaces/editRestPlaces");
        try {
            RestPlaces restPlaces = restPlacesService.findById(editRestPlaces.getId());
            if (!restPlaces.equals(editRestPlaces)) {
                byte[] photoBytes = photo.getBytes();
                editRestPlaces.setPhotoRestPlaces(photoBytes);
                restPlacesService.update(editRestPlaces);
                model.addAttribute("msg", "success");
                model.addAttribute("restPlacesList", restPlacesService.findAll());
            } else {
                model.addAttribute("msg", "same");
            }
        } catch (Exception e) {
            model.addAttribute("msg", "fail");
            logger.error("editRestPlaces: " + e.getMessage());
        }
        model.addAttribute("editTodo", editRestPlaces);
        return "editRestPlaces";
    }

}

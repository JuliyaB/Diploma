package com.Bondarenko.form;

public class RestPlacesForm {
    private byte photo;
    private String name;
    private String inf;
    private String map;

    public byte getPhoto() {
        return photo;
    }

    public void setPhoto(byte photo) {
        this.photo = photo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInf() {
        return inf;
    }

    public void setInf(String inf) {
        this.inf = inf;
    }
    public String getMap() {
        return map;
    }

    public void setMap(String map) {
        this.map = map;
    }
}

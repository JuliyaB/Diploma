package com.Bondarenko;

import org.apache.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.thymeleaf.extras.java8time.dialect.Java8TimeDialect;

@SpringBootApplication
@ComponentScan(basePackages = {"com.Bondarenko.controller"})
@ComponentScan(basePackages = {"com.Bondarenko.service"})
@ComponentScan(basePackages = {"com.Bondarenko.repository"})
public class Application implements WebMvcConfigurer {

    private final static org.apache.log4j.Logger logger = Logger.getLogger(Application.class);

    public static void main(String[] args){
        SpringApplication.run(Application.class, args);
        logger.info("Application Started");
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/static/**").addResourceLocations("classpath:/static/");
        registry.addResourceHandler("/webjars/**").addResourceLocations("/webjars/");

    }

    @Bean
    public Java8TimeDialect java8TimeDialect() {
        return new Java8TimeDialect();
    }
}

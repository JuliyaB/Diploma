package com.Bondarenko.model;

import javax.persistence.*;
import java.util.Base64;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "User", schema = "tododb")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", unique = true)
    private int id;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
    private List<DayTrip> dayTrips;

    @Lob
    @Column(name = "photo", columnDefinition="MEDIUMBLOB")
    private byte[] userPhoto;

    @Column(name = "name", nullable = false)
    private String username;

    @Column(name = "inf", columnDefinition="TEXT")
    private String inf;

    @Column(name = "password", nullable = false)
    private String password;

    @Transient
    @Column(name = "password_2", nullable = false)
    private String password_2;

    @Column(name = "email", nullable = false)
    private String email;

    @Column(name = "role", nullable = false)
    private int role;

    public User() {
    }

    public User( byte[] userPhoto, String username,String inf, String password, String email, int role) {
        this.setUserPhoto(userPhoto);
        this.setUsername(username);
        this.setInf(inf);
        this.setPassword(password);
        this.setEmail(email);
        this.setRole(role);

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<DayTrip> getDayTrip() {
        return dayTrips;
    }

    public void setDayTrip(List<DayTrip> dayTrips) {
        this.dayTrips = dayTrips;
    }

    public byte[] getUserPhoto() {
        return userPhoto;
    }

    public void setUserPhoto(byte[] userPhoto) {
        this.userPhoto = userPhoto;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getInf() {
        return inf;
    }

    public void setInf(String inf) {
        this.inf = inf;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword_2() {
        return password_2;
    }

    public void setPassword_2(String password_2) {
        this.password_2 = password_2;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getRole() {
        return role;
    }

    public void setRole(int role) {
        this.role = role;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return id == user.id &&
                role == user.role &&
                Objects.equals(userPhoto, user.userPhoto) &&
                Objects.equals(username, user.username) &&
                Objects.equals(password, user.password) &&
                Objects.equals(password_2, user.password_2) &&
                Objects.equals(inf, user.inf) &&
                Objects.equals(email, user.email);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, userPhoto, username, inf, password, password_2, email, role);
    }
}

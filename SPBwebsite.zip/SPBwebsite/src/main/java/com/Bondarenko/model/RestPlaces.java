package com.Bondarenko.model;

import javax.persistence.*;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "RestPlaces")
public class RestPlaces {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @ManyToMany(mappedBy = "dayTrip_restPlaces")
    Set<DayTrip> restPlaces_dayTrip;

    @Column(name = "photo", columnDefinition="MEDIUMBLOB", nullable = false)
    private byte[] photoRestPlaces;

    @Column(name = "name", nullable = false)
    private String nameRestPlaces;

    @Column(name = "inf", nullable = false, columnDefinition="TEXT")
    private String infRestPlaces;

    @Column(name = "mapA", nullable = false, columnDefinition="DOUBLE")
    private Double mapA;

    @Column(name = "mapB", nullable = false, columnDefinition="DOUBLE")
    private Double mapB;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_kind", nullable = false)
    private RestKinds restKinds;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Set<DayTrip> getRestPlaces_dayTrip() {
        return restPlaces_dayTrip;
    }

    public void setRestPlaces_dayTrip(Set<DayTrip> restPlaces_dayTrip) {
        this.restPlaces_dayTrip = restPlaces_dayTrip;
    }

    public byte[] getPhotoRestPlaces() {
        return photoRestPlaces;
    }

    public void setPhotoRestPlaces(byte[] photoRestPlaces) {
        this.photoRestPlaces = photoRestPlaces;
    }

    public String getNameRestPlaces() {
        return nameRestPlaces;
    }

    public void setNameRestPlaces(String nameRestPlaces) {
        this.nameRestPlaces = nameRestPlaces;
    }

    public String getInfRestPlaces() {
        return infRestPlaces;
    }

    public void setInfRestPlaces(String infRestPlaces) {
        this.infRestPlaces = infRestPlaces;
    }

    public Double getMapA() {
        return mapA;
    }

    public void setMapA(Double mapA) {
        this.mapA = mapA;
    }

    public Double getMapB() {
        return mapB;
    }

    public void setMapB(Double mapB) {
        this.mapB = mapB;
    }

    public RestKinds getRestKinds() {
        return restKinds;
    }

    public void setRestKinds(RestKinds restKinds) {
        this.restKinds = restKinds;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RestPlaces restPlaces = (RestPlaces) o;
        return id == restPlaces.id &&
                Objects.equals(photoRestPlaces, restPlaces.photoRestPlaces)&&
                Objects.equals(nameRestPlaces, restPlaces.nameRestPlaces)&&
                Objects.equals(infRestPlaces, restPlaces.infRestPlaces)&&
                mapA == restPlaces.mapA &&
                mapB == restPlaces.mapB;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, photoRestPlaces, nameRestPlaces, infRestPlaces, mapA, mapB);
    }
}

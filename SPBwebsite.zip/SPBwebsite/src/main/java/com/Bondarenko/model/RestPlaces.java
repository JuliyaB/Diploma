package com.Bondarenko.model;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "RestPlaces")
public class RestPlaces {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @ManyToMany(mappedBy = "dayTrip_restPlaces")
    Set<DayTrip> restPlaces_dayTrip;

    @Column(name = "photo", columnDefinition="BLOB")
    private byte photo;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "inf", nullable = false, columnDefinition="TEXT")
    private String inf;

    @Column(name = "map", nullable = false, columnDefinition="TEXT")
    private String map;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_kind", nullable = false)
    private RestKinds restKinds;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Set<DayTrip> getRestPlaces_dayTrip() {
        return restPlaces_dayTrip;
    }

    public void setRestPlaces_dayTrip(Set<DayTrip> restPlaces_dayTrip) {
        this.restPlaces_dayTrip = restPlaces_dayTrip;
    }

    public byte getPhoto() {
        return photo;
    }

    public void setPhoto(byte photo) {
        this.photo = photo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInf() {
        return inf;
    }

    public void setInf(String inf) {
        this.inf = inf;
    }

    public String getMap() {
        return map;
    }

    public void setMap(String map) {
        this.map = map;
    }

    public RestKinds getRestKinds() {
        return restKinds;
    }

    public void setRestKinds(RestKinds restKinds) {
        this.restKinds = restKinds;
    }
}

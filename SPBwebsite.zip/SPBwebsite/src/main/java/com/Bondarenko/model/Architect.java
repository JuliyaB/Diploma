package com.Bondarenko.model;

import javax.persistence.*;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "Architect", schema = "tododb")
public class Architect {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @ManyToMany(mappedBy = "architect_sights")
    private Set<Sights> sights_architect;

    @Column(name = "photo", columnDefinition = "MEDIUMBLOB", nullable = false)
    private byte[] photoArchitect;

    @Column(name = "name", nullable = false)
    private String architectName;

    @Column(name = "years_from", nullable = false)
    /*@Size(min = 3, max = 4)*/
    private Integer yearsFrom;

    @Column(name = "years_to", nullable = false)
    /*@Size(min = 3, max = 4)*/
    private Integer yearsTo;

    @Column(name = "biography", nullable = false, columnDefinition = "TEXT")
    private String architectBiography;

    public Architect() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Set<Sights> getSights_architect() {
        return sights_architect;
    }

    public void setSights_architect(Set<Sights> sights_architect) {
        this.sights_architect = sights_architect;
    }

    public byte[] getPhotoArchitect() {
        return photoArchitect;
    }

    public void setPhotoArchitect(byte[] photoArchitect) {
        this.photoArchitect = photoArchitect;
    }

    public String getArchitectName() {
        return architectName;
    }

    public void setArchitectName(String architectName) {
        this.architectName = architectName;
    }

    public Integer getYearsFrom() {
        return yearsFrom;
    }

    public void setYearsFrom(Integer yearsFrom) {
        this.yearsFrom = yearsFrom;
    }

    public Integer getYearsTo() {
        return yearsTo;
    }

    public void setYearsTo(Integer yearsTo) {
        this.yearsTo = yearsTo;
    }

    public String getArchitectBiography() {
        return architectBiography;
    }

    public void setArchitectBiography(String architectBiography) {
        this.architectBiography = architectBiography;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Architect architect = (Architect) o;
        return id == architect.id &&
                Objects.equals(architectName, architect.architectName) &&
                yearsFrom == architect.yearsFrom &&
                yearsTo == architect.yearsTo &&
                Objects.equals(architectBiography, architect.architectBiography);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, architectName, yearsFrom, yearsTo, architectBiography);
    }
}

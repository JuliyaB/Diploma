package com.Bondarenko.model;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "Architect", schema = "tododb")
public class Architect {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "architect")
    private List<Sights> sights;

    @Column(name = "photoArchitect", columnDefinition = "BLOB")
    private byte photoArchitect;

    @Column(name = "architectName", nullable = false)
    private String architectName;

    @Column(name = "years_from", nullable = false)
    /*@Size(min = 3, max = 4)*/
    private Integer yearsFrom;

    @Column(name = "years_to", nullable = false)
    /*@Size(min = 3, max = 4)*/
    private Integer yearsTo;

    @Column(name = "architectBiography", nullable = false, columnDefinition = "TEXT")
    private String architectBiography;

    public Architect() {
    }

    /*public Architect(*//* byte photoArchitect,*//* String nameArchitect, Integer yearsFrom, Integer yearsTo, String biographyArchitect) {
        *//*this.setPhotoArchitect(photoArchitect);*//*
        this.setNameArchitect(nameArchitect);
        this.setYearsFrom(yearsFrom);
        this.setYearsTo(yearsTo);
        this.setBiographyArchitect(biographyArchitect);
    }*/

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public List<Sights> getSights() {
        return sights;
    }

    public void setSights(List<Sights> sights) {
        this.sights = sights;
    }

    public byte getPhotoArchitect() {
        return photoArchitect;
    }

    public void setPhotoArchitect(byte photoArchitect) {
        this.photoArchitect = photoArchitect;
    }

    public String getArchitectName() {
        return architectName;
    }

    public void setArchitectName(String architectName) {
        this.architectName = architectName;
    }

    public Integer getYearsFrom() {
        return yearsFrom;
    }

    public void setYearsFrom(Integer yearsFrom) {
        this.yearsFrom = yearsFrom;
    }

    public Integer getYearsTo() {
        return yearsTo;
    }

    public void setYearsTo(Integer yearsTo) {
        this.yearsTo = yearsTo;
    }

    public String getArchitectBiography() {
        return architectBiography;
    }

    public void setArchitectBiography(String architectBiography) {
        this.architectBiography = architectBiography;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Architect architect = (Architect) o;
        return id == architect.id &&
                Objects.equals(architectName, architect.architectName) &&
                yearsFrom == architect.yearsFrom &&
                yearsTo == architect.yearsTo &&
                Objects.equals(architectBiography, architect.architectBiography);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, architectName, yearsFrom, yearsTo, architectBiography);
    }
}

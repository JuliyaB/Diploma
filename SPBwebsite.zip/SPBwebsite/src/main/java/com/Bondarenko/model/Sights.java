package com.Bondarenko.model;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "RestPlaces")
public class Sights {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @ManyToMany
    @JoinTable(
            name = "DayTrip_Sights",
            joinColumns = @JoinColumn(name = "id_sights"),
            inverseJoinColumns = @JoinColumn(name = "id_dayTrip"))
    Set<DayTrip> dayTrip_sights;

    @Column(name = "photo", nullable = false, columnDefinition="BLOB")
    private byte photo;

    @Column(name = "name", nullable = false)
    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_architect", nullable = false)
    private Architect architect;

    @Column(name = "history", nullable = false, columnDefinition="TEXT")
    private String history;

    @Column(name = "map", nullable = false, columnDefinition="TEXT")
    private String map;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_kind", nullable = false)
    private SightKinds sightKinds;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Set<DayTrip> getDayTrip_sights() {
        return dayTrip_sights;
    }

    public void setDayTrip_sights(Set<DayTrip> dayTrip_sights) {
        this.dayTrip_sights = dayTrip_sights;
    }

    public byte getPhoto() {
        return photo;
    }

    public void setPhoto(byte photo) {
        this.photo = photo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Architect getArchitect() {
        return architect;
    }

    public void setArchitect(Architect architect) {
        this.architect = architect;
    }

    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history;
    }

    public String getMap() {
        return map;
    }

    public void setMap(String map) {
        this.map = map;
    }

    public SightKinds getSightKinds() {
        return sightKinds;
    }

    public void setSightKinds(SightKinds sightKinds) {
        this.sightKinds = sightKinds;
    }
}

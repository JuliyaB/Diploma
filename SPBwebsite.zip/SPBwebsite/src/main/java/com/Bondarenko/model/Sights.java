package com.Bondarenko.model;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "Sights")
public class Sights {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @ManyToMany(mappedBy = "sights_dayTrip")
    Set<DayTrip> dayTrip_sights;

    @Column(name = "photo", nullable = false, columnDefinition="MEDIUMBLOB")
    private byte[] photoSights;

    @Column(name = "name", nullable = false)
    private String nameSights;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(
            name = "sights_architect",
            joinColumns = @JoinColumn(name = "id_sights"),
            inverseJoinColumns = @JoinColumn(name = "id_architect"))
    Set<Architect> architect_sights=new HashSet<Architect>();

    @Column(name = "history", nullable = false, columnDefinition="TEXT")
    private String historySights;

    @Column(name = "mapA", nullable = false, columnDefinition="DOUBLE")
    private Double mapA;

    @Column(name = "mapB", nullable = false, columnDefinition="DOUBLE")
    private Double mapB;

    @ManyToOne(optional = false, cascade = CascadeType.ALL)
    @JoinColumn(name = "id_kind", nullable = false)
    private SightKinds sightKinds;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Set<DayTrip> getDayTrip_sights() {
        return dayTrip_sights;
    }

    public void setDayTrip_sights(Set<DayTrip> dayTrip_sights) {
        this.dayTrip_sights = dayTrip_sights;
    }

    public byte[] getPhotoSights() {
        return photoSights;
    }

    public void setPhotoSights(byte[] photoSights) {
        this.photoSights = photoSights;
    }

    public String getNameSights() {
        return nameSights;
    }

    public void setNameSights(String nameSights) {
        this.nameSights = nameSights;
    }

    public Set<Architect> getArchitect_sights() {
        return architect_sights;
    }

    public void setArchitect_sights(Set<Architect> architect_sights) {
        this.architect_sights = architect_sights;
    }

    public String getHistorySights() {
        return historySights;
    }

    public void setHistorySights(String historySights) {
        this.historySights = historySights;
    }

    public Double getMapA() {
        return mapA;
    }

    public void setMapA(Double mapA) {
        this.mapA = mapA;
    }

    public Double getMapB() {
        return mapB;
    }

    public void setMapB(Double mapB) {
        this.mapB = mapB;
    }

    public SightKinds getSightKinds() {
        return sightKinds;
    }

    public void setSightKinds(SightKinds sightKinds) {
        this.sightKinds = sightKinds;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Sights sights = (Sights) o;
        return id == sights.id &&
                Objects.equals(photoSights, sights.photoSights)&&
                Objects.equals(nameSights, sights.nameSights)&&
                Objects.equals(historySights, sights.historySights)&&
                mapA == sights.mapA &&
                mapB == sights.mapB;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, photoSights, nameSights, historySights, mapA, mapB);
    }
}

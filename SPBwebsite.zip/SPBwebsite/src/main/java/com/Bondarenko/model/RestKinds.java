package com.Bondarenko.model;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "RestKinds")
public class RestKinds {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "restKinds")
    private List<RestPlaces> restPlaces;

    @Column(name = "name", nullable = false)
    private String name;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public List<RestPlaces> getRestPlaces() {
        return restPlaces;
    }

    public void setRestPlaces(List<RestPlaces> restPlaces) {
        this.restPlaces = restPlaces;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

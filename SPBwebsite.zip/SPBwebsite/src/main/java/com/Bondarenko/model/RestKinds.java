package com.Bondarenko.model;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "RestKinds")
public class RestKinds {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "restKinds")
    private List<RestPlaces> restPlaces;

    @Column(name = "name", nullable = false)
    private String nameRestKinds;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public List<RestPlaces> getRestPlaces() {
        return restPlaces;
    }

    public void setRestPlaces(List<RestPlaces> restPlaces) {
        this.restPlaces = restPlaces;
    }

    public String getNameRestKinds() {
        return nameRestKinds;
    }

    public void setNameRestKinds(String nameRestKinds) {
        this.nameRestKinds = nameRestKinds;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RestKinds restKinds = (RestKinds) o;
        return id == restKinds.id &&
                Objects.equals(nameRestKinds, restKinds.nameRestKinds);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nameRestKinds);
    }
}

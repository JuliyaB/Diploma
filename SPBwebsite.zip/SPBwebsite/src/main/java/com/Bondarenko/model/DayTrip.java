package com.Bondarenko.model;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "DayTrip")
public class DayTrip {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(
            name = "dayTrip_restPlaces",
            joinColumns = @JoinColumn(name = "id_dayTrip"),
            inverseJoinColumns = @JoinColumn(name = "id_restPlaces"))
    Set<RestPlaces> dayTrip_restPlaces = new HashSet<RestPlaces>();

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(
            name = "dayTrip_sights",
            joinColumns = @JoinColumn(name = "id_dayTrip"),
            inverseJoinColumns = @JoinColumn(name = "id_sights"))
    Set<Sights> sights_dayTrip = new HashSet<Sights>();

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "dayTrip")
    private Set<Photos> photoDayTrip;

    @Column(name = "name", nullable = false)
    private String nameDayTrip;

    @Column(name = "inf", nullable = false, columnDefinition = "TEXT")
    private String infDayTrip;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_user", nullable = false)
    private User user;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Set<RestPlaces> getDayTrip_restPlaces() {
        return dayTrip_restPlaces;
    }

    public void setDayTrip_restPlaces(Set<RestPlaces> dayTrip_restPlaces) {
        this.dayTrip_restPlaces = dayTrip_restPlaces;
    }

    public Set<Sights> getSights_dayTrip() {
        return sights_dayTrip;
    }

    public void setSights_dayTrip(Set<Sights> sights_dayTrip) {
        this.sights_dayTrip = sights_dayTrip;
    }

    public Set<Photos> getPhotoDayTrip() {
        return photoDayTrip;
    }

    public void setPhotoDayTrip(Set<Photos> photoDayTrip) {
        this.photoDayTrip = photoDayTrip;
    }

    public String getNameDayTrip() {
        return nameDayTrip;
    }

    public void setNameDayTrip(String nameDayTrip) {
        this.nameDayTrip = nameDayTrip;
    }

    public String getInfDayTrip() {
        return infDayTrip;
    }

    public void setInfDayTrip(String infDayTrip) {
        this.infDayTrip = infDayTrip;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DayTrip dayTrip = (DayTrip) o;
        return id == dayTrip.id &&
                Objects.equals(nameDayTrip, dayTrip.nameDayTrip) &&
                Objects.equals(infDayTrip, dayTrip.infDayTrip);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nameDayTrip, infDayTrip);
    }

}

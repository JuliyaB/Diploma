package com.Bondarenko.model;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "DayTrip")
public class DayTrip {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @ManyToMany
    @JoinTable(
            name = "dayTrip_restPlaces",
            joinColumns = @JoinColumn(name = "id_dayTrip"),
            inverseJoinColumns = @JoinColumn(name = "id_sights"))
    Set<RestPlaces> dayTrip_restPlaces;

    @ManyToMany(mappedBy = "dayTrip_sights")
    Set<Sights> sights_dayTrip;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_photo", nullable = false)
    private Photos photo;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "inf", nullable = false, columnDefinition="TEXT")
    private String inf;

    @Column(name = "map", nullable = false, columnDefinition="TEXT")
    private String map;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_user", nullable = false)
    private User user;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Set<RestPlaces> getDayTrip_restPlaces() {
        return dayTrip_restPlaces;
    }

    public void setDayTrip_restPlaces(Set<RestPlaces> dayTrip_restPlaces) {
        this.dayTrip_restPlaces = dayTrip_restPlaces;
    }

    public Set<Sights> getSights_dayTrip() {
        return sights_dayTrip;
    }

    public void setSights_dayTrip(Set<Sights> sights_dayTrip) {
        this.sights_dayTrip = sights_dayTrip;
    }

    public Photos getPhoto() {
        return photo;
    }

    public void setPhoto(Photos photo) {
        this.photo = photo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInf() {
        return inf;
    }

    public void setInf(String inf) {
        this.inf = inf;
    }

    public String getMap() {
        return map;
    }

    public void setMap(String map) {
        this.map = map;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

}

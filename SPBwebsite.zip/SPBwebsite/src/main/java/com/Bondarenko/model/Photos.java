package com.Bondarenko.model;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "Photos")
public class Photos {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(name = "photo", nullable = false, columnDefinition = "MEDIUMBLOB")
    private byte[] photoDay;

    @Column(name = "description", nullable = false, columnDefinition = "TEXT")
    private String description;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_dayTrip")
    private DayTrip dayTrip;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public byte[] getPhotoDay() {
        return photoDay;
    }

    public void setPhotoDay(byte[] photoDay) {
        this.photoDay = photoDay;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public DayTrip getDayTrip() {
        return dayTrip;
    }

    public void setDayTrip(DayTrip dayTrip) {
        this.dayTrip = dayTrip;
    }
}

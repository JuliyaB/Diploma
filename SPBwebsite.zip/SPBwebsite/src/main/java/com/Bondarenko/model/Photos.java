package com.Bondarenko.model;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "Photos")
public class Photos {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(name = "photo", nullable = false, columnDefinition="BLOB")
    private byte photo;

    @Column(name = "description", nullable = false, columnDefinition="TEXT")
    private String description;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "photo")
    private List<DayTrip> dayTrips;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public byte getPhoto() {
        return photo;
    }

    public void setPhoto(byte photo) {
        this.photo = photo;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<DayTrip> getDayTrip() {
        return dayTrips;
    }

    public void setDayTrip(List<DayTrip> dayTrips) {
        this.dayTrips = dayTrips;
    }
}

package com.Bondarenko.model;

import javax.persistence.*;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "SightKinds")
public class SightKinds {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "sightKinds")
    private Set<Sights> sights;

    @Column(name = "name", nullable = false)
    private String nameSightKinds;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Set<Sights> getSights() {
        return sights;
    }

    public void setSights(Set<Sights> sights) {
        this.sights = sights;
    }

    public String getNameSightKinds() {
        return nameSightKinds;
    }

    public void setNameSightKinds(String nameSightKinds) {
        this.nameSightKinds = nameSightKinds;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SightKinds sightKinds = (SightKinds) o;
        return id == sightKinds.id &&
                Objects.equals(nameSightKinds, sightKinds.nameSightKinds);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nameSightKinds);
    }
}

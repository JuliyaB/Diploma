package com.Bondarenko.repository;

import com.Bondarenko.model.Sights;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SightsRepository extends CrudRepository<Sights, Integer> {

    Sights findByNameSights(String nameSights);

    @Query(value = "select * from Sights e where e.name like %:keyword% or e.history like %:keyword%", nativeQuery = true)
    List<Sights> findByKeyword(@Param("keyword") String keyword);
}

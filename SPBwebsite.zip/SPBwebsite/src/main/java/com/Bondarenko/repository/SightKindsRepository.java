package com.Bondarenko.repository;

import com.Bondarenko.model.SightKinds;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SightKindsRepository extends CrudRepository<SightKinds, Integer> {

    SightKinds findByNameSightKinds(String nameSightKinds);
}

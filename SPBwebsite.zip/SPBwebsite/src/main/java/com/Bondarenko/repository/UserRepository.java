package com.Bondarenko.repository;

import com.Bondarenko.model.User;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends CrudRepository<User, Integer> {

    User findByUsername(String username);

    User findByEmail(String email);

    @Query(value = "select * from User e where e.name like %:keyword% or e.inf like %:keyword%", nativeQuery = true)
    List<User> findByKeyword(@Param("keyword") String keyword);

}
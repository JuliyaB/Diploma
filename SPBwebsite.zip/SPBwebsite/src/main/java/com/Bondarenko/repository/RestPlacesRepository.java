package com.Bondarenko.repository;

import com.Bondarenko.model.RestPlaces;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RestPlacesRepository extends CrudRepository<RestPlaces, Integer> {

    RestPlaces findByNameRestPlaces(String nameRestPlaces);

    @Query(value = "select * from Rest_Places e where e.name like %:keyword% or e.inf like %:keyword%", nativeQuery = true)
    List<RestPlaces> findByKeyword(@Param("keyword") String keyword);
}

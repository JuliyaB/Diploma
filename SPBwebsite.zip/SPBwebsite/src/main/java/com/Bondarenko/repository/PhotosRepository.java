package com.Bondarenko.repository;

import com.Bondarenko.model.Photos;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PhotosRepository extends CrudRepository<Photos, Integer> {

    @Query(value = "select * from Photos e where e.description like %:keyword%", nativeQuery = true)
    List<Photos> findByKeyword(@Param("keyword") String keyword);
}

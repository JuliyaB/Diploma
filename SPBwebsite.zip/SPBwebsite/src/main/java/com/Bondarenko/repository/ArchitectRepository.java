package com.Bondarenko.repository;

import com.Bondarenko.model.Architect;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ArchitectRepository extends CrudRepository<Architect, Integer> {

    Architect findByArchitectName(String nameSightKinds);

    @Query(value = "select * from Architect e where e.name like %:keyword% or e.biography like %:keyword%", nativeQuery = true)
    List<Architect> findByKeyword(@Param("keyword") String keyword);
}

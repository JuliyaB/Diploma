package com.Bondarenko.repository;

import com.Bondarenko.model.Architect;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ArchitectRepository extends CrudRepository<Architect, Integer> {

    Architect findByArchitectName(String architectName);
}

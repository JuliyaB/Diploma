package com.Bondarenko.repository;

import com.Bondarenko.model.RestKinds;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RestKindsRepository extends CrudRepository<RestKinds, Integer> {

    RestKinds findByNameRestKinds(String nameRestKinds);
}

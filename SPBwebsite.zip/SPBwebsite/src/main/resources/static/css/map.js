ymaps.ready(init);
function init(){
    var myMap = new ymaps.Map("map", {
        center: [59.94, 30.32],
        zoom: 13,
        controls: ['zoomControl'],
        behaviors: ['drag']
    });

    var placemark = new ymaps.Placemark([a1, b1],{

    });
    myMap.geoObjects.add(placemark);
}
$("window").load(function() {
  $("body").removeAttr("id");
});
